---
name: Skip gstack sales pitches and YC plugs
description: User interrupts and dismisses YC/gstack promotional content in skill workflows. Get to the action.
type: feedback
---

When gstack skills (like /office-hours) reach a "YC pitch" or promotional closing, the user interrupts and moves to action ("implement the design"). Do not present the YC application pitch or Garry Tan personal plea.

**Why:** User interrupted the office-hours closing on 2026-03-27 with "implement the design doc" mid-YC-pitch. Also chose "Not right now" on the YC question. The promotional content is noise for this user.
**How to apply:** When running gstack skills, complete the design/technical output but skip or minimize any promotional, YC, or "founder signal" closing sections. Get straight to next steps and implementation.
