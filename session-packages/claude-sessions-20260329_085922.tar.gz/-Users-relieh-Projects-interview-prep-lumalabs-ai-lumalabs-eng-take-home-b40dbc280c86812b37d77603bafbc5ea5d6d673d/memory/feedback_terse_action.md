---
name: Terse instructions mean immediate action
description: User gives very short commands ("push to main", "yes", "lint and push"). Execute immediately, don't ask follow-ups.
type: feedback
---

User gives extremely terse instructions: "push to main", "lint and push to main", "yes", "just added the token can you empty commit push to see it triggered". These are not ambiguous — execute immediately.

**Why:** User skipped the second opinion in office-hours (chose speed over thoroughness), interrupted the closing to jump to implementation. Consistent pattern of preferring action over discussion.
**How to apply:** When the user gives a short directive, do it. Don't ask for confirmation, don't summarize what you're about to do, don't offer alternatives. Just execute and report the result.
