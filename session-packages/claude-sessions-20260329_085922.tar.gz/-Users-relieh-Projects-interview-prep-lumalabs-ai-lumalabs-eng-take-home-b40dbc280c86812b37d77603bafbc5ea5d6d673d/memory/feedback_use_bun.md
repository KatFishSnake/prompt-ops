---
name: Use bun for package management
description: User prefers bun over npm for installing JavaScript/TypeScript packages
type: feedback
---

Use `bun` instead of `npm` for package management (install, add, etc.).

**Why:** User explicitly corrected npm usage to bun.
**How to apply:** Whenever installing JS/TS packages, use `bun add` instead of `npm install`.
