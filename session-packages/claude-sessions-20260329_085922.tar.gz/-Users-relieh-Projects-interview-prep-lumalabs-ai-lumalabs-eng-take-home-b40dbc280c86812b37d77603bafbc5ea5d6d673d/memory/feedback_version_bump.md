---
name: Auto-increment frontend version
description: User wants package.json version bumped (patch) on every frontend commit
type: feedback
---

Auto-increment the frontend package.json version (patch bump) on every commit that includes frontend changes.

**Why:** The version is displayed in the sidebar for dev purposes. Keeping it in sync with releases means the user can always tell which build they're looking at.

**How to apply:** When committing frontend changes, bump the patch version in frontend/package.json before committing.
