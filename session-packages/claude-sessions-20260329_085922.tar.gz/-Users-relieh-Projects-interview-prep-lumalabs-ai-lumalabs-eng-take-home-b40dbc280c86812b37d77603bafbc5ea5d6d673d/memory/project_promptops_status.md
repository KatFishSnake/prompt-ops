---
name: PromptOps take-home status
description: Luma Labs take-home challenge #3 — prompt management platform. Deployed live, scenario builder shipped 2026-03-27.
type: project
---

Luma Labs engineering take-home (challenge #3: managing prompt & model behavior in production).

Built PromptOps — prompt management and replay platform. Core loop: version → replay → compare → promote.

**Status as of 2026-03-29:** V1.1 shipped with scenario builder.
- Backend: FastAPI + Celery + Postgres + Redis
- Frontend: Next.js 16 + Tailwind v4
- Major feature: AI-powered scenario builder (generate test scenarios from domain description, run against active prompt, save as real traces). Closes the cold-start gap — full eval loop works without leaving the browser.
- Deployed: Backend on Railway, Frontend on Vercel
  - Backend: https://backend-production-fa0f.up.railway.app
  - Frontend: https://prompt-ops-katfishsnakes-projects.vercel.app
- CI: GitHub Actions workflow deploys backend+worker to Railway on push to main (path filter: backend/**)
- Alembic migrations: 001 (initial), 002 (scenario_jobs)
- Design doc: ~/.gstack/projects/KatFishSnake-prompt-ops/relieh-main-design-20260327-173032.md

**Why:** Take-home submission for Luma Labs. The scenario builder is the differentiating feature — self-contained eval loop that no competitor offers.
**How to apply:** Project is in polish/iterate phase. User pushes directly to main. Focus on making the demo experience flawless.
