---
name: User tooling and workflow preferences
description: User uses gstack skills, bun, Biome, Ruff. Prefers concise autonomous execution. GitHub: KatFishSnake.
type: user
---

- GitHub username: **KatFishSnake** (repo: KatFishSnake/prompt-ops)
- Uses **gstack skill suite** for planning: /office-hours → /plan-eng-review → /plan-design-review, often via /autoplan
- Prefers **bun** over npm (see feedback_use_bun.md)
- Uses **Biome.js** for frontend linting/formatting (configured in frontend/biome.json)
- Uses **Ruff** for Python backend linting/formatting (configured in backend/pyproject.toml)
- Files may be auto-reformatted by linters between sessions — treat reformatted files as intentional
- Delegates large implementation tasks with "implement the plan" — expects autonomous execution from design docs
- Pushes directly to main on solo projects (no PR workflow for take-homes)
- Very terse communication style — see feedback_terse_action.md
